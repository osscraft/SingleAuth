package com.dcux.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.dcux.config.Config;

public class SSOToOAuth2 {
	public static String authorizeURL = "http://192.168.0.23/SSO/src/authorize.php";
	public static String accessTokenURL = "http://192.168.0.23/SSO/src/token.php";
	public static String logoutURL = "http://192.168.0.23/SSO/src/logout.php";

	private String clientId;
	private String clientSecret;
	private String access_token;
	private String refresh_token;
	private String timeout = "30";
	private String connectTimeout = "30";
	
	private static SSOToOAuth2 instance = null;
	
	public static SSOToOAuth2 getInstance(){
		if(instance == null){
			instance = new SSOToOAuth2();
		}
		return instance;
	}
	
	protected SSOToOAuth2(){
		this.clientId = Config.SSO_CLIENT_ID;
		this.clientSecret = Config.SSO_CLIENT_SECRET;
	}
	

	/**
	 * authorize�ӿ�
	 * @param string url ��Ȩ��Ļص���ַ
	 * @param string response_type ֧�ֵ�ֵ���� code ��token Ĭ��ֵΪcode
	 * @param string state ���ڱ�������ͻص���״̬���ڻص�ʱ,����Query Parameter�лش��ò���
	 * @return String
	 */
	public String getAuthorizeURL(String response_type,String state) {
		String client_id = Config.SSO_CLIENT_ID;
		String redirect_uri = Config.SSO_CALLBACK;
		return authorizeURL + "?" + "client_id=" + client_id + "&redirect_uri="
				+ redirect_uri + "&response_type=" + response_type + "&state="
				+ state;
	} 

	/**
	 * access_token�ӿ�
	 * @param String type ���������,����Ϊ:code, token
	 * @param Map keys ���������� ��typeΪcodeʱ�� ��code��redirectURI ��typeΪtokenʱ����refresh_token
	 * @return String
	 */
	public Map<String, String> getAccessToken(String type,Map<String, String> keys) {
		String code = keys.get("code");
		String grant_type = null;
		String uri = null;
		//typeĬ��Ϊcode
		if (type == null || type == "") { 
			type = "code";
		}
		
		if (type == "token") {
			grant_type = "refresh_token";
			uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
			+ "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
			+ grant_type + "&refresh_token=" + keys.get("refresh_token");
		} 
		else if (type == "code") {
			grant_type = "authorization_code";
			uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
			+ "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
			+ grant_type + "&code=" + code + "&redirect_uri="
			+ Config.SSO_CALLBACK;
		}
		else if(type == "password"){
			grant_type = "password";
			uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
			+ "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
			+ grant_type + "&username=" + keys.get("username") + "&password="
			+ keys.get("password");
		}
		else{
			uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
				+ "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
				+ grant_type + "&code=" + code + "&redirect_uri="
				+ Config.SSO_CALLBACK;
		}
		String response = urlConnection(uri);
		// ������Ҫ�����������ﴦ��response�ַ���
		return jsonToMap(response);
	}

	public Map<String,String> logout() {
		String json = urlConnection(logoutURL + "?access_token=" + this.access_token);	
		return jsonToMap(json);
	}

	protected String urlConnection(String link) {
		StringBuilder responseBuilder = null;
		BufferedReader reader = null;
		OutputStreamWriter wr = null;
		URL url;
		URLConnection conn = null;
		try {
			url = new URL(link);
			conn = url.openConnection();
			conn.setDoOutput(true);
			conn.setConnectTimeout(5000);
			wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write("");
			wr.flush();

			// response
			reader = new BufferedReader(new InputStreamReader(conn
					.getInputStream()));
			responseBuilder = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				responseBuilder.append(line + "\n");
			}
			wr.close();
			reader.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		// System.out.println(responseBuilder.toString());
		return responseBuilder.toString();
	}

	// JSON.simple��һ���򵥵�Java��⣬���ڽ���������JSON�ı�����������������⣬���ܸߡ�
	protected Map<String, String> jsonToMap(String json) {
		// String j = "{\"access_token\":\"1bbee65fe3690665694290873fb65a5b\",\"token_type\":\"access\",\"expires_in\":43200}";
		Map<String, String> token = new HashMap<String, String>();
		Object obj = JSONValue.parse(json);
		JSONObject jsonObject = (JSONObject) obj;
		String error = (String) jsonObject.get("error");
		if((String)jsonObject.get("access_token") != null){
			String access_token = (String) jsonObject.get("access_token");
			String token_type = (String) jsonObject.get("token_type");
			String expires_in = ((Long) jsonObject.get("expires_in")).toString();
			String refresh_token = (String) jsonObject.get("refresh_token");
			this.access_token = access_token;
			this.refresh_token = refresh_token;
			token.put("access_token", access_token);
			token.put("token_type", token_type);
			token.put("expires_in", expires_in);
			token.put("refresh_token", refresh_token);
		}
		if((String) jsonObject.get("logout") != null){
			String logout = (String) jsonObject.get("logout");
			token.put("logout", logout);	
		}
		if((String) jsonObject.get("uid") != null){
			String uid = (String) jsonObject.get("uid");
			String username = (String) jsonObject.get("username");
			String role = (String) jsonObject.get("role");
			token.put("uid", uid);
			token.put("username", username);
			token.put("role", role);
		}
		if(error != null){
			token.put("error", error);
		}
		token.put("json", json);
		// System.out.println(token.get("access_token") +
		// token.get("token_type")+ token.get("expires_in"));
		return token;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String accessToken) {
		access_token = accessToken;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refreshToken) {
		refresh_token = refreshToken;
	}

	public String getTimeout() {
		return timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	public String getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(String connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

}

