using System;
namespace Com.Dcux
{
    /// <summary>
    /// Config ��ժҪ˵��
    /// </summary>
    public class Config
    {

        public static String SSO_CLIENT_ID = "asp.netSDKExample";
        public static String SSO_CLIENT_SECRET = "1c0fb63135b6b3c34aca3148789d51d2";
        public static String SSO_CALLBACK = "http://localhost:4737/callback.aspx";
    }
}
