package com.dcux.service;

import java.util.Map;

public class SSOClient extends SSOToOAuth2{
	public static String resourceURL = "http://192.168.0.22/SSO/src/resource.php";

	private static SSOClient instance = null;
	
	public static SSOClient getInstance(){
		if(instance == null){
			instance = new SSOClient();
		}
		return instance;
	}
	
	private SSOClient() {
		super();
	}

	public Map<String,String> getUserInfo(String access_token) {
		 String json = urlConnection(resourceURL + "?access_token=" + access_token);
		 //System.out.println("access_token: "+access_token);
		 //System.out.println("super.getAccess_token(): "+super.getAccess_token());
		 //System.out.println(json);
		 return jsonToMap(json);
	}
}
