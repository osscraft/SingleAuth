package com.dcux.config;

public class Config {
	public static String SSO_CLIENT_ID  = "javaSDKexample";
	public static String SSO_CLIENT_SECRET  = "831ecb0ae1f56b711ab4e944cf0981a3";
	public static String SSO_CALLBACK  = "http://localhost:8080/example/callback.jsp";	
}
