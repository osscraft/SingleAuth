<?php
session_start();

include_once 'config.php';
include_once 'SSOToOAuth2.php';
$oauth = new SSOToOAuth2($CFG['SSO_CLIENT_ID'], $CFG['SSO_CLIENT_SECRET']);
$url   = $oauth->getAuthorizeURL($CFG['SSO_CALLBACK']);

$token = $_SESSION['example']['token'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SSO Example Index</title>
</head>
<body>
<?php
if($token) {
?>
    <p>Access Token:<?php echo $token['access_token'];?></p>
    <p>Token Type:<?php echo $token['token_type'];?></p>
    <p>Expires In:<?php echo $token['expires_in'];?></p>
    <p><a href="logout.php">退出</a></p>
<?php
} else {
?>
	<!-- 授权按钮 -->
    <p><a href="<?=$url;?>"><img src="http://sso.lixin.edu.cn/images/login_48.png" title="点击进入授权页面" alt="点击进入授权页面" border="0" /></a></p>
</body>
</html>
<?php
}
?>
