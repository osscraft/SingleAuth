<?php
global $CFG;
$CFG['SSO_CLIENT_ID'] = 'example';
$CFG['SSO_CLIENT_SECRET'] = '123456';
$CFG['SSO_CALLBACK'] = 'http://localhost/SSO/src/example/callback.php';
?>
