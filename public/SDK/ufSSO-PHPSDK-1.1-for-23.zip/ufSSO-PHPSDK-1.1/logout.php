<?php
session_start();

include_once 'config.php';
include_once 'SSOToOAuth2.php';

$token = $_SESSION['example']['token'];
$oauth = new SSOToOAuth2($CFG['SSO_CLIENT_ID'], $CFG['SSO_CLIENT_SECRET']);
$oauth->access_token = $token['access_token'];
$oauth->refresh_token = $token['refresh_token'];

unset($_SESSION['example']['token']);
//header("HTTP/1.1 302 Found");
//header("Location: " . $oauth->getLogoutURL());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SSO Example Logout</title>
</head>
<body>
	<a href="index.php">进入你的页面</a>
</body>
</html>
