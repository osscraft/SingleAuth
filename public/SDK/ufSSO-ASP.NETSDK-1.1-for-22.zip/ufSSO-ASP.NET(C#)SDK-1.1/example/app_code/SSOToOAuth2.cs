using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using System.Xml;
using System.Net;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace Com.Dcux
{

    public class SSOToOAuth2
    {

        public static String authorizeURL = "http://192.168.0.22/SSO/src/authorize.php";
        public static String accessTokenURL = "http://192.168.0.22/SSO/src/token.php";
        public static String logoutURL = "http://192.168.0.22/SSO/src/logout.php";

        private String clientId;
        private String clientSecret;
        private String access_token;
        private String refresh_token;
        private String timeout = "30";
        private String connectTimeout = "30";

        private static SSOToOAuth2 instance = null;

        public static SSOToOAuth2 getInstance()
        {
            if (instance == null)
            {
                instance = new SSOToOAuth2();
            }
            return instance;
        }

        protected SSOToOAuth2()
        {
            this.clientId = Config.SSO_CLIENT_ID;
            this.clientSecret = Config.SSO_CLIENT_SECRET;
        }


        /**
         * authorize�ӿ�
         * @param string url ��Ȩ��Ļص���ַ
         * @param string response_type ֧�ֵ�ֵ���� code ��token Ĭ��ֵΪcode
         * @param string state ���ڱ�������ͻص���״̬���ڻص�ʱ,����Query Parameter�лش��ò���
         * @return String
         */
        public String GetAuthorizeURL(String response_type, String state)
        {
            String client_id = Config.SSO_CLIENT_ID;
            String redirect_uri = Config.SSO_CALLBACK;
            return authorizeURL + "?" + "client_id=" + client_id + "&redirect_uri="
                    + redirect_uri + "&response_type=" + response_type + "&state="
                    + state;
        }

        /**
         * access_token�ӿ�
         * @param String type ���������,����Ϊ:code, token
         * @param Dictionary keys ���������� ��typeΪcodeʱ�� ��code��redirectURI ��typeΪtokenʱ����refresh_token
         * @return String
         */

        public Dictionary<String, object> GetAccessToken(String type, Dictionary<String, String> keys)
        {
            String code = keys["code"];
            String grant_type = null;
            String uri = null;
            //typeĬ��Ϊcode
            if (type == null || type == "")
            {
                type = "code";
            }

            if (type == "token")
            {
                grant_type = "refresh_token";
                uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
                + "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
                + grant_type + "&refresh_token=" + keys["refresh_token"];
            }
            else if (type == "code")
            {
                grant_type = "authorization_code";
                uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
                + "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
                + grant_type + "&code=" + code + "&redirect_uri="
                + Config.SSO_CALLBACK;
            }
            else if (type == "password")
            {
                grant_type = "password";
                uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
                + "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
                + grant_type + "&username=" + keys["username"] + "&password="
                + keys["password"];
            }
            else
            {
                uri = accessTokenURL + "?client_id=" + Config.SSO_CLIENT_ID
                    + "&client_secret=" + Config.SSO_CLIENT_SECRET + "&grant_type="
                    + grant_type + "&code=" + code + "&redirect_uri="
                    + Config.SSO_CALLBACK;
            }
            String response = SendGetHttpRequest(uri);
            // ������Ҫ�����������ﴦ��response�ַ���  JsonToDictionary(response)
            Dictionary<String, object> result = JsonToDictionary(response);
            return result;
        }

        
        public Dictionary<String, object> Logout()
        {
            String jsonString = SendGetHttpRequest(logoutURL + "?access_token=" + this.access_token);
            return JsonToDictionary(jsonString);
        }

        protected String SendGetHttpRequest(String link)
        {
            System.Net.HttpWebRequest request = null;
            System.Net.HttpWebResponse response = null;
            String jsonString = null;
            try
            {

                request = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(link);
                request.Method = "get";
                response = (HttpWebResponse)request.GetResponse();
              
                Stream stream = response.GetResponseStream();
                StreamReader sr = new StreamReader(stream,Encoding.UTF8);
                jsonString = sr.ReadToEnd();
            }
            catch (Exception ex)
            {
                //���԰����������쳣
            }
            finally {

            }
            //Dictionary<String, object> result = JsonToDictionary(jsonString);
            return jsonString;
        }


        protected Dictionary<String, object> JsonToDictionary(String jsonString)
        {
            // String j = "{\"access_token\":\"1bbee65fe3690665694290873fb65a5b\",\"token_type\":\"access\",\"expires_in\":43200}";
            Dictionary<String, object> token = new Dictionary<String, object>();
           jsonString = jsonString.Replace("\"", "").Replace("{", "").Replace("}", "");
            string strTemp = "";
            for (int i = 0; i < jsonString.Split(',').Length; i++)
            {
                strTemp = jsonString.Split(',')[i].ToString();
                token.Add(strTemp.Split(':')[0], strTemp.Split(':')[1]);
            }   
           
            if (token.ContainsKey("access_token") && token["access_token"] != null)
            {
                String access_token = (String)token["access_token"];
                String token_type = (String)token["token_type"];
                String expires_in = (String)token["expires_in"];
                this.access_token = access_token;
                if (token.ContainsKey("refresh_token") && token["refresh_token"] != null)
                {
                    String refresh_token = (String)token["refresh_token"];
                    this.refresh_token = refresh_token;
                }
                
                //token.Add("access_token", access_token);
                //token.Add("token_type", token_type);
                //token.Add("expires_in", expires_in);
                //token.Add("refresh_token", refresh_token);
            }
            if (token.ContainsKey("logout") && (String)token["logout"] != null)
            {
                String logout = (String)token["logout"];
                //token.Add("logout", logout);
            }
            if (token.ContainsKey("uid") && (String)token["uid"] != null)
            {
                String uid = (String)token["uid"];
                String username = (String)token["username"];
                String role = (String)token["role"];
                //token.Add("uid", uid);
                //token.Add("username", username);
                //token.Add("role", role);
            }
            if (token.ContainsKey("error") && token["error"] != null)
            {
                //token.Add("error", error);
            }
            token.Add("json",jsonString);
            
            return token;
        }
        

        public String getClientId()
        {
            return clientId;
        }

        public void setClientId(String clientId)
        {
            this.clientId = clientId;
        }

        public String getClientSecret()
        {
            return clientSecret;
        }

        public void setClientSecret(String clientSecret)
        {
            this.clientSecret = clientSecret;
        }

        public String getAccess_token()
        {
            return access_token;
        }

        public void setAccess_token(String accessToken)
        {
            access_token = accessToken;
        }

        public String getRefresh_token()
        {
            return refresh_token;
        }

        public void setRefresh_token(String refreshToken)
        {
            refresh_token = refreshToken;
        }

        public String getTimeout()
        {
            return timeout;
        }

        public void setTimeout(String timeout)
        {
            this.timeout = timeout;
        }

        public String getConnectTimeout()
        {
            return connectTimeout;
        }

        public void setConnectTimeout(String connectTimeout)
        {
            this.connectTimeout = connectTimeout;
        }

    }
}
