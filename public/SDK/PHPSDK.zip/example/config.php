<?php
global $CFG;
$CFG['SSO_CLIENT_ID'] = 'example';
$CFG['SSO_CLIENT_SECRET'] = 'b379de87b397daac6ccaf4ad50b1df3b';
$CFG['SSO_CALLBACK'] = 'http://210.35.100.79/example/callback.php';?>
