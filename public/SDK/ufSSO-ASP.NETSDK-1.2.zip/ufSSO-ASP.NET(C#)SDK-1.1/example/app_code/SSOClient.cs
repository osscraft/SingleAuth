using System;
using System.Collections.Generic;

/// <summary>
/// SSOClient ��ժҪ˵��
/// </summary>

namespace Com.Dcux
{
    public class SSOClient : SSOToOAuth2
    {
        public static String resourceURL = "http://sso.lixin.edu.cn/resource.php";

        private static SSOClient instance = null;

        public static SSOClient getInstance()
        {
            if (instance == null)
            {
                instance = new SSOClient();
            }
            return instance;
        }

        private SSOClient()
        {

        }

        
        public Dictionary<String,object> GetUserInfo(String access_token)
        {
             String json = SendGetHttpRequest(resourceURL + "?access_token=" + access_token);
             return JsonToDictionary(json);
        }
        
    }
}
